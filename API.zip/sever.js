const express = require('express');
const {spawn} = require('child_process');
const app = express();
const port = 3000;
// Require the upload middleware
const uploadBody = require('./uploadBody');
// Add headers before the routes are defined
app.use('/public', express.static('public'))
app.use(function (req, res, next) {

  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin', '*');

  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)

  // Pass to next layer of middleware
  next();
});
// Set up a route for file uploads
app.post('/uploadBody',     uploadBody.single('file'),(req, res) => {
  res.header("Access-Control-Allow-Origin", "*")
        // Handle the uploaded file
        res.status(200).json({ message: 'File uploaded successfully!' });
});
app.get('/matchDNA/:bodyFileName/:parentFileName' ,(req, res) => {
  res.header("Access-Control-Allow-Origin", "*")
        // Handle the uploaded file
  try {
      console.log('hi')
      const python = spawn('python3', ['lcs.py', req.params.bodyFileName, req.params.parentFileName]);
      // collect data from script
      python.stdout.on('data', function (data) {
       console.log('Pipe data from python script ...');
        dataToSend = data.toString();
      });
      // in close event we are sure that stream from child process is closed
      python.on('close', (code) => {
      console.log(`child process close all stdio with code ${code}`);
      });
        res.status(200).json('done');
  }
  catch {
    res.status(500)
  }
        
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
``